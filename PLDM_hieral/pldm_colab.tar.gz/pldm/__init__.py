"""
PLDM is an implementation of planning with 
joint-embedding predictive architectures (JEPA).
"""
